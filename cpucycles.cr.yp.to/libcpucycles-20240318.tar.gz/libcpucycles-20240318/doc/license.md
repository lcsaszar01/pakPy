libcpucycles is hereby placed into the public domain.

[SPDX-License-Identifier](https://spdx.dev/ids/):
[LicenseRef-PD-hp](https://cr.yp.to/spdx.html)
OR
[CC0-1.0](https://spdx.org/licenses/CC0-1.0.html)
OR
[0BSD](https://spdx.org/licenses/0BSD.html)
OR
[MIT-0](https://spdx.org/licenses/MIT-0.html)
OR
[MIT](https://spdx.org/licenses/MIT.html)
